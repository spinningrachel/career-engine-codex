---
name: role-localization
description: Execute the localization role in the Career Engine pipeline on Codex.
---

> **Codex host:** Before using this document, read `${CAREER_ENGINE_ROOT}/CODEX-RUNTIME.md`. Resolve the root from this skill’s installed path. That contract replaces Claude-specific APIs, installation, personal-data discovery, and role spawning; all career doctrine, gates, and required reads below still apply.

Read `${CAREER_ENGINE_ROOT}/agents/localization.md` and execute that role with the supplied inputs and file-based output protocol. Its frontmatter describes the upstream host; use the Codex runtime contract for tool access and role execution.
