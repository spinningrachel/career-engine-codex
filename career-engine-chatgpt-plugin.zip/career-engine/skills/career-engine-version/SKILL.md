---
name: career-engine-version
description: Report the loaded Career Engine package version and check for a published update.
---


## Loaded package version

Package build: `1.0.0+upstream.1db550bccbee.chat.ed5d68348fe8`

Upstream commit: `1db550bccbee03a04feea9592772cd9c13259fbc`

These values identify the package loaded with this skill, not an account release ID. On “Career Engine version”, “was Career Engine updated?”, or “check for updates”, report these embedded values first. When authorized fetch is available, read https://raw.githubusercontent.com/spinningrachel/career-engine-codex/main/chatgpt-plugin-version.json and report its package_version and upstream_commit separately as Latest published. Equal package_version means this loaded build matches the published package; a different value means a different published build is available (do not order SemVer build metadata). If fetching fails, state Latest published: unknown; never assume this chat upgraded. Never use the remote version as the loaded version. A newly published ZIP does not update this chat. If this stamp is absent in an older installation, report Loaded build: unknown. Applying an account update and opening a fresh chat may be necessary to load new instructions.
